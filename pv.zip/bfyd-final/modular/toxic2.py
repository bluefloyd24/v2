import asyncio

from pyrogram import *

from Mix import *


#@ky.ubot("ngentot")
#async def _(c: nlx, m):
#  if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
#        return
#    pler = await m.reply("**WOYY NGENTOD!!**", reply_to_message_id=ReplyCheck(m))
#    await asyncio.sleep(1.8)
#    await pler.edit("**JANGAN SOK JAGOAN DAH LU**")
#    await asyncio.sleep(1.8)
#   await pler.edit("**MUKA MASIH KAYA KONTOL AJA**")
#    await asyncio.sleep(1.8)
#    await pler.edit("**BANGGA LU HAHAHAHA**")
#    await asyncio.sleep(1.8)
#    await pler.edit("**COBA DEH NGACA MUKA LU KAN HINA BANGET**")
#    await asyncio.sleep(1.8)
#    await pler.edit("**HAHAHAHA**")
#    await asyncio.sleep(1.8)
#    await pler.edit("**MAKANYA GANTENG KONTOL**")
#    await asyncio.sleep(1.8)
#    await pler.edit("**BIAR MUKALU GAK DIHINA TERUS**")
#    await asyncio.sleep(1.8)
#    await pler.edit("**SAMA ORANG LAIN**")
#   await asyncio.sleep(1.8)
#    await pler.edit("**HAHAHAHA**")


# Create by myself @localheart


#@ky.ubot("goblok")
#async def _(c: nlx, m):
#    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
#        return
#    puki = await m.reply("**WOYY GOBLOK!!**", reply_to_message_id=ReplyCheck(m))
#    await asyncio.sleep(1.8)
#    await puki.edit("**KO LU GOBLOK BANGET SIH**")
#    await asyncio.sleep(1.8)
#    await puki.edit("**OTAK LU TUH KAYA KONTOL**")
#    await asyncio.sleep(1.8)
#    await puki.edit("**YANG LEMBEK KETIKA LEMAH**")
#    await asyncio.sleep(1.8)
#    await puki.edit("**DAN KERAS KETIKA LU SANGE GOBLOK**")
#    await asyncio.sleep(1.8)
 #   await puki.edit("**HAHAHAHA**")
#    await asyncio.sleep(1.8)
 #   await puki.edit("**MAKANYA JANGAN SANGEAN MULU**")
  #  await asyncio.sleep(1.8)
##    await puki.edit("**MUKA LU AJA KAYA ASPAL JALANAN**")
 #   await asyncio.sleep(1.8)
 #   await puki.edit("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
#    await asyncio.sleep(1.8)
 #   await puki.edit("**HAHAHAHA**")


# Create by myself @localheart


#@ky.ubot("ngatain")
#async def _(c: nlx, m):
 #   if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
 #       return
# #   kon = await m.reply("**BABI!!**", reply_to_message_id=ReplyCheck(m))
#    await asyncio.sleep(1.8)
#    await kon.edit("**MUKA LU KAYA BABI**")
 #   await asyncio.sleep(1.8)
#    await kon.edit("**OTAK LU TUH KAYA KONTOL**")
#    await asyncio.sleep(1.8)
 #   await kon.edit("**MUKA LU HINA BANGET**")
#    await asyncio.sleep(1.8)
#    await kon.edit("**OTAK LU KAYA BATU**")
#    await asyncio.sleep(1.8)
#    await kon.edit("**HAHAHAHA**")
#    await asyncio.sleep(1.8)
#    await kon.edit("**MAKANYA JANGAN SANGEAN MULU**")
#    await asyncio.sleep(1.8)
#    await kon.edit("**KONTOL LU AJA MASIH BENGKOK**")
 #   await asyncio.sleep(1.8)
#    await kon.edit("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
#    await asyncio.sleep(1.8)
#    await kon.edit("**HAHAHAHA**")

# Create by myself @localheart


#@ky.ubot("yatim")
#async def _(c: nlx, m):
#    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
#        return
#    mek = await m.reply(
 #       "`Hai Anak Kontol 🙈, Jangan Lupa Makan Yaa`", reply_to_message_id=ReplyCheck(m)
#    )
#    await asyncio.sleep(1.8)
#    await mek.edit("`Jangan Bilang Lu Ga Dikasih Makan Sama Ortu 😁`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`APA PERLU GUA SANTUNIN ?? 🙈🙈 xixixi`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`OH IYAA LUPAAA, LU KAN BEBAN KELUARGA 🤣`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`MANA MUNGKIN ORTU LU PEDULII xixixi 🙈`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`KETAWA DULU BOLEH KALI YAA 😁`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`HAHAHAHAHAHAHA`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`KASIAN ORTUNYAA GAPEDULIII 🙈🤣`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`MAAF YA, CANDAA BEBANNNN xixixi 🙈`")
#    await asyncio.sleep(1.8)
#    await mek.edit("`Tapi Bo'ong Hiyahiyahiya`")


#@ky.ubot("kont")
#async def _(c: nlx, m):
#    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
#        return
#    putt = await m.reply("**WOYY NGENTOD!!**", reply_to_message_id=ReplyCheck(m))
#    await asyncio.sleep(1.8)
#    await putt.edit("**LU ANAK KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**DI BIKIN DARI KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**MUKALU PERSIS KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**DASAR ANAK NGONTOLLLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**NOLEP KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**NGERUSUH KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**BENER BENER KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**PADAHAL LO GAPUNYA KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**MENDING LO OPERASI KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**BIAR LO PUNYA KONTOLL**")
#    await asyncio.sleep(1.8)
#    await putt.edit("**KASIAN CACAD GAPUNYA KONTOLL**")
