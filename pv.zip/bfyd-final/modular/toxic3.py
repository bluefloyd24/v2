# Part Of Ayiin-Userbot

import asyncio

from pyrogram import *

from Mix import *


#@ky.ubot("ceking")
#async def _(c: nlx, m):
#    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
#        return
#    sepong = await m.reply(
#        "**GIGI KUNING MATA MERAH BADAN KURUS CEKING EMANG PANTES...**",
#        reply_to_message_id=ReplyCheck(m),
#    )

#    await asyncio.sleep(1.8)
#    await sepong.edit("**DI KENCINGIN JAHANAM**")
#    await asyncio.sleep(1.8)
##    await sepong.edit("**ORANG KAYA LUH ITU...**")
#    await asyncio.sleep(1.8)
#    await sepong.edit("**CUMAN SEMPIT SEMPITIN ISI DUNIA DOANG KONTOL SEMPAK**")
#    await asyncio.sleep(1.8)
#    await sepong.edit("**GUA KASIH TAU NIH YAH USUS LUH TUH UDAH MELINTIR KONTOL**")
#    await asyncio.sleep(1.8)
#    await sepong.edit("**KERONGKONGAN LUH ITU UDAH RUSAK TOLOL...**")
 #   await asyncio.sleep(1.8)
#    await sepong.edit(
#        "**MASIH AJA MAKSAIN BUAT ADU ROASTING AMA GUA BEGO BANGET SIH LUH...**"
#    )


#@ky.ubot("hina")
#async def _(c: nlx, m):
#    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
##        return
#    Kon = await m.reply("**IZIN PANTUN BANG...**", reply_to_message_id=ReplyCheck(m))
#    await asyncio.sleep(1.8)
#    await Kon.edit("**KETEMU SI MAMAS DIAJAKIN KE CIBINONG...**")
#    await asyncio.sleep(1.8)
#    await Kon.edit("**PULANG NYE DIANTERIN MAKE KOPAJA...**")
 #   await asyncio.sleep(1.8)
#    await Kon.edit("**EH BOCAH AMPAS TITISAN DAJJAL...**")
 #   await asyncio.sleep(1.8)
#    await Kon.edit("**MUKA HINA KEK ODONG ODONG**")
#    await asyncio.sleep(1.8)
#    await Kon.edit("**GA USAH SO KERAS DEH LU KALO MENTAL BLOM SEKERAS BAJA...**")
  #  await asyncio.sleep(1.8)
#    await Kon.edit("**LUH ITU MANUSIA...**")
# #   await asyncio.sleep(1.8)
#    await Kon.edit("**MANUSIA HINA YANG DI CIPTAKAN DENGAN SECARA HINA**")
#    await asyncio.sleep(1.8)
#    await Kon.edit(
#        "**MANUSIA HINA YANG DI CIPTAKAN DENGAN SECARA HINA EMANG PANTES UNTUK DI HINA HINA...**"
#    )
#

#@ky.ubot("ngaca")
#async def _(c: nlx, m):
#    if m.reply_to_message and m.reply_to_message.from_user.id in DEVS:
#        await m.reply("**AKUN LO MO ILANG BANGSAT??**")
 #       return
#    omek = await m.reply(
#        "**IZIN NUMPANG PANTUN BANG...**", reply_to_message_id=ReplyCheck(m)
#    )
#    await asyncio.sleep(1.8)
#    await omek.edit("**BELI SEPATU KACA KE CHINA...**")
#    await asyncio.sleep(1.8)
#    await omek.edit("**ASEEEKKKK 🤪**")
#    await asyncio.sleep(1.8)
#    await omek.edit("**NGACA DULU BARU NGEHINA KONTOL...**")
  ##  await asyncio.sleep(1.8)
#    await omek.edit("**UDAH BULUK ITEM PENDEK BERPONI BAJU KEGEDEAN KAYAK JAMET**")
#    await asyncio.sleep(1.8)
#    await omek.edit(
#        "**UDAH BULUK ITEM PENDEK BERPONI BAJU KEGEDEAN KAYAK JAMET SOK-SOK AN MAU NGEHINA GUA KONTOL**"
#    )
#    await asyncio.sleep(1.8)
#    await omek.edit("**KENA KAN MENTAL LU...**")
